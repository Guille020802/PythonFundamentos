# error de sintaxis, 
prin(x)


# error en tiempo de ejecución
# cuando ejecuto e ingreso un dato inesperado, mi programa se falla
num = int(input('INgrese un numero: '))
print(num)
